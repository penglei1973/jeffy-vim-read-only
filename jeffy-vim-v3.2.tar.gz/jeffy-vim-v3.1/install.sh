#!/bin/bash

echo "This install will NOT backup your old vim files."
echo -n "Do you want to backup your old vim files. [y,n]? "
read ret
if test $ret == y ; then
    echo "tar -czvf ~/vim_config.tar.gz ~/.vimrc ~/.vim"
    tar -czvf ~/vim_config.tar.gz ~/.vimrc ~/.vim
fi

### install new files
echo -n "Install new vim files..."
# remove old files
rm -rf ~/.vim ~/.vimrc
# copy new files
cp -r ./vimfile ~/.vim
cp ./vimrc ~/.vimrc
# remove all hidden files, such as .svn ...
find ~/.vim -type d -name '.svn' | xargs rm -rf
echo "done!" 

### finish install
echo "install finished, enjoy yourself!"
